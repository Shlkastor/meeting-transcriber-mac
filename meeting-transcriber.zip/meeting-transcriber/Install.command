#!/bin/zsh
# Double-click ONCE on a new Mac. Installs everything the transcriber needs.
# Needs internet (about 1.5 GB download, only the first time).
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export HF_HUB_DISABLE_XET=1

pause() { echo; read -k 1 "?Press any key to close"; }
fail() { echo; echo "❌ $1"; pause; exit 1; }

echo "=== Meeting Transcriber - installation ==="
echo

# 0. Remove the macOS "downloaded from internet" block from this folder
xattr -dr com.apple.quarantine . 2>/dev/null
chmod +x Start.command Install.command 2>/dev/null

# 1. uv (installs Python and packages by itself)
if command -v uv >/dev/null 2>&1; then
  echo "✅ uv already installed"
else
  echo "⬇️  Installing uv (official installer from astral.sh)..."
  curl -LsSf https://astral.sh/uv/install.sh | sh || fail "Could not install uv. Check your internet connection."
  export PATH="$HOME/.local/bin:$PATH"
  command -v uv >/dev/null 2>&1 || fail "uv was installed but was not found. Close this window and run Install.command again."
fi

# 2. Python packages
echo
echo "⬇️  Installing Python and packages..."
uv sync || fail "Package installation failed."

# 3. Hebrew speech model
echo
echo "⬇️  Downloading the Hebrew speech model (about 1.5 GB, only the first time)..."
for attempt in 1 2 3; do
  uv run python -c "from huggingface_hub import snapshot_download; snapshot_download('ivrit-ai/whisper-large-v3-turbo-ct2')" && ok=1 && break
  echo "Attempt $attempt failed, retrying..."
done
[ "$ok" = 1 ] || fail "Model download failed. Check your internet connection and run Install.command again."

echo
echo "✅ All done! Now double-click Start.command to open the app."
echo "   Tips: use Chrome or Edge. The first time, allow microphone access."
pause
