"""Transcribe an audio/video file locally with Whisper (Hebrew-tuned by default).

Usage:
  uv run transcribe.py recordings/meeting.wav
  uv run transcribe.py file.m4a --model large-v3 --language en
  uv run transcribe.py file.wav --speakers 2      # needs: uv sync --extra speakers + HF_TOKEN
Outputs next to the input: .txt (with timestamps), .srt, .json
"""
import argparse
import json
import os
from pathlib import Path

from faster_whisper import WhisperModel

DEFAULT_MODEL = "ivrit-ai/whisper-large-v3-turbo-ct2"  # Hebrew fine-tune


def ts(seconds: float, srt: bool = False) -> str:
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    if srt:
        return f"{h:02}:{m:02}:{s:02},{ms:03}"
    return f"{h:02}:{m:02}:{s:02}" if h else f"{m:02}:{s:02}"


def diarize(audio_path: str, n_speakers: int):
    from pyannote.audio import Pipeline

    token = os.environ.get("HF_TOKEN")
    if not token:
        raise SystemExit("Set HF_TOKEN (free Hugging Face token) to use --speakers")
    pipe = Pipeline.from_pretrained("pyannote/speaker-diarization-3.1", use_auth_token=token)
    result = pipe(audio_path, num_speakers=n_speakers)
    return [(t.start, t.end, spk) for t, _, spk in result.itertracks(yield_label=True)]


def speaker_at(turns, start: float, end: float) -> str:
    mid = (start + end) / 2
    for s, e, spk in turns:
        if s <= mid <= e:
            return spk
    return "?"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("audio")
    p.add_argument("--model", default=DEFAULT_MODEL)
    p.add_argument("--language", default="he")
    p.add_argument("--speakers", type=int, default=0, help="number of speakers (0 = off)")
    args = p.parse_args()

    audio = Path(args.audio)
    model = WhisperModel(args.model, device="cpu", compute_type="int8")
    segments, info = model.transcribe(
        str(audio), language=args.language, vad_filter=True, beam_size=5
    )

    turns = diarize(str(audio), args.speakers) if args.speakers else None

    rows = []
    for seg in segments:
        spk = speaker_at(turns, seg.start, seg.end) if turns else None
        rows.append({"start": seg.start, "end": seg.end, "speaker": spk, "text": seg.text.strip()})
        print(f"[{ts(seg.start)}] {spk + ': ' if spk else ''}{seg.text.strip()}", flush=True)

    txt = []
    for r in rows:
        who = f"{r['speaker']}: " if r["speaker"] else ""
        txt.append(f"[{ts(r['start'])}] {who}{r['text']}")
    audio.with_suffix(".txt").write_text("\n".join(txt) + "\n", encoding="utf-8")

    srt = []
    for i, r in enumerate(rows, 1):
        who = f"{r['speaker']}: " if r["speaker"] else ""
        srt.append(f"{i}\n{ts(r['start'], True)} --> {ts(r['end'], True)}\n{who}{r['text']}\n")
    audio.with_suffix(".srt").write_text("\n".join(srt), encoding="utf-8")
    audio.with_suffix(".json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"\nSaved {audio.with_suffix('.txt')} (+ .srt, .json)")


if __name__ == "__main__":
    main()
