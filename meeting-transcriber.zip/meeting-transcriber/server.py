"""Local web app: record in the browser, transcribe locally with Whisper.

Start by double-clicking "Start.command" (or: uv run server.py).
Everything stays on this computer (server listens on 127.0.0.1 only).

Recording audio is streamed to disk WHILE recording (/start, /chunk, /finish),
so a closed tab or a crash never loses the meeting - it can be transcribed
later from the history list.
"""
import datetime as dt
import json
import re
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from transcribe import DEFAULT_MODEL, ts

ROOT = Path(__file__).parent
REC_DIR = ROOT / "recordings"
REC_DIR.mkdir(exist_ok=True)
PORT = 8765
AUDIO_EXTS = (".webm", ".wav", ".m4a", ".mp3", ".mp4", ".ogg")

_model = None
_model_lock = threading.Lock()
JOBS: dict[str, dict] = {}
SESSIONS: dict[str, dict] = {}  # live recordings: id -> {path, name, lang}
_sessions_lock = threading.Lock()


def get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel

            _model = WhisperModel(DEFAULT_MODEL, device="cpu", compute_type="int8")
        return _model


def run_job(job_id: str, audio: Path, language: str | None) -> None:
    job = JOBS[job_id]
    try:
        job["status"] = "loading"
        model = get_model()
        job["status"] = "transcribing"
        rows = []
        # The VAD filter skips silence, but on short or quiet clips it can drop
        # everything. If it finds nothing, retry once without it.
        for use_vad in (True, False):
            segments, info = model.transcribe(
                str(audio), language=language, vad_filter=use_vad, beam_size=5
            )
            job["duration"] = info.duration
            for seg in segments:
                text = seg.text.strip()
                if not text:
                    continue
                rows.append({"start": seg.start, "end": seg.end, "text": text})
                job["segments"] = list(rows)
                job["progress"] = min(1.0, seg.end / info.duration) if info.duration else 0
            if rows:
                break
        txt = "\n".join(f"[{ts(r['start'])}] {r['text']}" for r in rows) + "\n"
        audio.with_suffix(".txt").write_text(txt, encoding="utf-8")
        srt = "\n".join(
            f"{i}\n{ts(r['start'], True)} --> {ts(r['end'], True)}\n{r['text']}\n"
            for i, r in enumerate(rows, 1)
        )
        audio.with_suffix(".srt").write_text(srt, encoding="utf-8")
        job["status"] = "done"
        job["progress"] = 1.0
    except Exception as e:  # noqa: BLE001 - surface any failure to the UI
        job["status"] = "error"
        job["error"] = str(e)


def start_job(audio: Path, lang: str) -> dict:
    language = None if lang == "auto" else lang
    job_id = uuid.uuid4().hex[:8]
    JOBS[job_id] = {"status": "queued", "progress": 0, "segments": [], "name": audio.stem}
    threading.Thread(target=run_job, args=(job_id, audio, language), daemon=True).start()
    return {"job": job_id, "name": audio.stem}


def find_audio(stem: str) -> Path | None:
    for ext in AUDIO_EXTS:
        p = REC_DIR / f"{stem}{ext}"
        if p.is_file():
            return p
    return None


def list_recordings() -> list[dict]:
    stems = {p.stem for p in REC_DIR.iterdir() if p.suffix in AUDIO_EXTS + (".txt",)}
    items = []
    for stem in sorted(stems, reverse=True):
        audio = find_audio(stem)
        txt = REC_DIR / f"{stem}.txt"
        text = txt.read_text(encoding="utf-8") if txt.is_file() else None
        items.append(
            {
                "name": stem,
                "text": text,
                "audio": audio.name if audio else None,
                "audio_size": audio.stat().st_size if audio else 0,
            }
        )
    return items


SAFE = re.compile(r"^[\w\-. ]+$")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # keep console quiet
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path: Path, ctype: str, download: bool = False):
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if download:
            self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self) -> bytes:
        n = int(self.headers.get("Content-Length", 0))
        out = bytearray()
        while len(out) < n:
            chunk = self.rfile.read(min(1 << 20, n - len(out)))
            if not chunk:
                break
            out += chunk
        return bytes(out)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            return self._file(ROOT / "index.html", "text/html; charset=utf-8")
        if u.path == "/ping":
            return self._json({"ok": True})
        if u.path.startswith("/job/"):
            job = JOBS.get(u.path.split("/")[-1])
            return self._json(job or {"status": "unknown"}, 200 if job else 404)
        if u.path == "/recordings":
            return self._json(list_recordings())
        if u.path.startswith("/files/"):
            name = unquote(u.path[len("/files/"):])
            p = REC_DIR / name
            if SAFE.match(name) and p.is_file():
                ctype = "text/plain; charset=utf-8" if p.suffix in (".txt", ".srt") else "application/octet-stream"
                return self._file(p, ctype, download=True)
        self.send_error(404)

    def do_POST(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)

        # 1) start a live recording: creates the audio file on disk
        if u.path == "/start":
            label = re.sub(r"[^\w\- ]", "", q.get("name", [""])[0]).strip()
            stamp = dt.datetime.now().strftime("%Y-%m-%d-%H%M")
            base = f"{stamp}{' ' + label if label else ''}"
            name, i = base, 2
            while any((REC_DIR / f"{name}{e}").exists() for e in AUDIO_EXTS):
                name, i = f"{base}-{i}", i + 1
            path = REC_DIR / f"{name}.webm"
            path.touch()
            sid = uuid.uuid4().hex[:10]
            with _sessions_lock:
                SESSIONS[sid] = {"path": path, "name": name, "lang": q.get("lang", ["he"])[0]}
            return self._json({"id": sid, "name": name})

        # 2) append a chunk of audio (sent every second while recording)
        if u.path == "/chunk":
            s = SESSIONS.get(q.get("id", [""])[0])
            if not s:
                return self._json({"error": "unknown session"}, 404)
            data = self._read_body()
            with _sessions_lock, open(s["path"], "ab") as f:
                f.write(data)
            return self._json({"ok": True, "size": s["path"].stat().st_size})

        # 3) recording stopped: transcribe
        if u.path == "/finish":
            s = SESSIONS.pop(q.get("id", [""])[0], None)
            if not s:
                return self._json({"error": "unknown session"}, 404)
            if s["path"].stat().st_size < 2000:  # accidental click, nothing recorded
                s["path"].unlink(missing_ok=True)
                return self._json({"error": "empty recording"}, 400)
            return self._json(start_job(s["path"], s["lang"]))

        # transcribe (or re-transcribe) a saved recording from the history list
        if u.path == "/retranscribe":
            audio = find_audio(unquote(q.get("name", [""])[0]))
            if not audio or not SAFE.match(audio.name):
                return self._json({"error": "not found"}, 404)
            return self._json(start_job(audio, q.get("lang", ["he"])[0]))

        # legacy: upload a whole file at once
        if u.path == "/transcribe":
            ext = re.sub(r"[^a-z0-9]", "", (q.get("ext", ["webm"])[0]).lower()) or "webm"
            label = re.sub(r"[^\w\- ]", "", q.get("name", [""])[0]).strip()
            stamp = dt.datetime.now().strftime("%Y-%m-%d-%H%M")
            audio = REC_DIR / f"{stamp}{' ' + label if label else ''}.{ext}"
            audio.write_bytes(self._read_body())
            return self._json(start_job(audio, q.get("lang", ["he"])[0]))

        self.send_error(404)


def main() -> None:
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://localhost:{PORT}"
    print(f"Meeting Transcriber running at {url}  (close this window to stop)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
