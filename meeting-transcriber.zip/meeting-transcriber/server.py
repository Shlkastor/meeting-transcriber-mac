"""Local web app: record in the browser, transcribe locally with Whisper.

Start by double-clicking "Start.command" (or: uv run server.py).
Everything stays on this computer (server listens on 127.0.0.1 only).
"""
import datetime as dt
import json
import re
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from transcribe import DEFAULT_MODEL, ts

ROOT = Path(__file__).parent
REC_DIR = ROOT / "recordings"
REC_DIR.mkdir(exist_ok=True)
PORT = 8765

_model = None
_model_lock = threading.Lock()
JOBS: dict[str, dict] = {}


def get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel

            _model = WhisperModel(DEFAULT_MODEL, device="cpu", compute_type="int8")
        return _model


def run_job(job_id: str, audio: Path, language: str | None) -> None:
    job = JOBS[job_id]
    try:
        job["status"] = "loading"
        model = get_model()
        job["status"] = "transcribing"
        rows = []
        # The VAD filter skips silence, but on short or quiet clips it can drop
        # everything. If it finds nothing, retry once without it.
        for use_vad in (True, False):
            segments, info = model.transcribe(
                str(audio), language=language, vad_filter=use_vad, beam_size=5
            )
            job["duration"] = info.duration
            for seg in segments:
                text = seg.text.strip()
                if not text:
                    continue
                rows.append({"start": seg.start, "end": seg.end, "text": text})
                job["segments"] = list(rows)
                job["progress"] = min(1.0, seg.end / info.duration) if info.duration else 0
            if rows:
                break
        txt = "\n".join(f"[{ts(r['start'])}] {r['text']}" for r in rows) + "\n"
        audio.with_suffix(".txt").write_text(txt, encoding="utf-8")
        srt = "\n".join(
            f"{i}\n{ts(r['start'], True)} --> {ts(r['end'], True)}\n{r['text']}\n"
            for i, r in enumerate(rows, 1)
        )
        audio.with_suffix(".srt").write_text(srt, encoding="utf-8")
        job["status"] = "done"
        job["progress"] = 1.0
    except Exception as e:  # noqa: BLE001 - surface any failure to the UI
        job["status"] = "error"
        job["error"] = str(e)


SAFE = re.compile(r"^[\w\-. ]+$")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):  # keep console quiet
        pass

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path: Path, ctype: str, download: bool = False):
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if download:
            self.send_header("Content-Disposition", f'attachment; filename="{path.name}"')
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        if u.path in ("/", "/index.html"):
            return self._file(ROOT / "index.html", "text/html; charset=utf-8")
        if u.path.startswith("/job/"):
            job = JOBS.get(u.path.split("/")[-1])
            return self._json(job or {"status": "unknown"}, 200 if job else 404)
        if u.path == "/recordings":
            items = []
            for p in sorted(REC_DIR.glob("*.txt"), reverse=True):
                items.append({"name": p.stem, "text": p.read_text(encoding="utf-8")})
            return self._json(items)
        if u.path.startswith("/files/"):
            name = unquote(u.path[len("/files/"):])
            p = REC_DIR / name
            if SAFE.match(name) and p.is_file():
                ctype = "text/plain; charset=utf-8" if p.suffix in (".txt", ".srt") else "application/octet-stream"
                return self._file(p, ctype, download=True)
        self.send_error(404)

    def do_POST(self):
        u = urlparse(self.path)
        if u.path != "/transcribe":
            return self.send_error(404)
        q = parse_qs(u.query)
        ext = re.sub(r"[^a-z0-9]", "", (q.get("ext", ["webm"])[0]).lower()) or "webm"
        lang = q.get("lang", ["he"])[0]
        language = None if lang == "auto" else lang
        label = re.sub(r"[^\w\- ]", "", q.get("name", [""])[0]).strip()
        stamp = dt.datetime.now().strftime("%Y-%m-%d-%H%M")
        name = f"{stamp}{' ' + label if label else ''}"
        audio = REC_DIR / f"{name}.{ext}"
        n = int(self.headers.get("Content-Length", 0))
        with open(audio, "wb") as f:
            left = n
            while left > 0:
                chunk = self.rfile.read(min(1 << 20, left))
                if not chunk:
                    break
                f.write(chunk)
                left -= len(chunk)
        job_id = uuid.uuid4().hex[:8]
        JOBS[job_id] = {"status": "queued", "progress": 0, "segments": [], "name": name}
        threading.Thread(target=run_job, args=(job_id, audio, language), daemon=True).start()
        self._json({"job": job_id, "name": name})


def main() -> None:
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://localhost:{PORT}"
    print(f"Meeting Transcriber running at {url}  (close this window to stop)")
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
