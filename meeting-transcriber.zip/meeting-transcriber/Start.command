#!/bin/zsh
# Double-click to start the meeting transcriber. Close this window to stop it.
cd "$(dirname "$0")"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
export HF_HUB_DISABLE_XET=1
if ! command -v uv >/dev/null 2>&1; then
  echo "uv is not installed. Install it from https://docs.astral.sh/uv/ and try again."
  read -k 1 "?Press any key to close"
  exit 1
fi
uv run server.py
