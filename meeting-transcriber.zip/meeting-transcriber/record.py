"""Record a meeting from an input device until Ctrl+C.

Usage:
  uv run record.py --list                  # show input devices
  uv run record.py                         # default mic
  uv run record.py --device "BlackHole 2ch"  # system audio (needs BlackHole)
Output: recordings/meeting-YYYY-MM-DD-HHMM.wav
"""
import argparse
import datetime as dt
import queue
import sys
from pathlib import Path

import sounddevice as sd
import soundfile as sf

SAMPLE_RATE = 16000  # Whisper's native rate


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--list", action="store_true", help="list input devices and exit")
    p.add_argument("--device", help="input device name or index")
    p.add_argument("--out", help="output wav path")
    args = p.parse_args()

    if args.list:
        print(sd.query_devices())
        return

    out = Path(args.out) if args.out else Path("recordings") / dt.datetime.now().strftime(
        "meeting-%Y-%m-%d-%H%M.wav"
    )
    out.parent.mkdir(parents=True, exist_ok=True)

    device = args.device
    if device is not None and device.isdigit():
        device = int(device)

    q: "queue.Queue" = queue.Queue()

    def callback(indata, frames, time, status):
        if status:
            print(status, file=sys.stderr)
        q.put(indata.copy())

    print(f"Recording to {out} - press Ctrl+C to stop")
    try:
        with sf.SoundFile(out, mode="w", samplerate=SAMPLE_RATE, channels=1) as f, sd.InputStream(
            samplerate=SAMPLE_RATE, channels=1, device=device, callback=callback
        ):
            while True:
                f.write(q.get())
    except KeyboardInterrupt:
        print(f"\nSaved {out}")


if __name__ == "__main__":
    main()
